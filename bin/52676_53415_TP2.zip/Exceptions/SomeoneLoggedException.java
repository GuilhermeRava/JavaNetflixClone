package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description someone logged exception
 */
public class SomeoneLoggedException extends RuntimeException {
	private static final long serialVersionUID = 1L;
public SomeoneLoggedException() {
	super();
}
}
