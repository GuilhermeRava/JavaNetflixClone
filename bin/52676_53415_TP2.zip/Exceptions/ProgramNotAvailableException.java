package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description Program not available exception
 */
public class ProgramNotAvailableException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	public ProgramNotAvailableException() {
		super();
	}
}
