package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description client already logged in
 */
public class ClientLoggedInException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public ClientLoggedInException() {
		super();
	}
}
