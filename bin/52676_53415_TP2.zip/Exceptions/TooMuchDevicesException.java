package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description Too much devices exception
 */
public class TooMuchDevicesException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public TooMuchDevicesException() {
		super();
	}
}
