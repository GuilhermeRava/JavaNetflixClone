package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description no program with parameter exception
 */
public class NoProgramWithParameterException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public NoProgramWithParameterException() {
		super();
	}
}
