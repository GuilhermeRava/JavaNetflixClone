package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description Program doesnt exist exception
 */
public class ProgramDoesntExistException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	public ProgramDoesntExistException() {
		super();
	}
}
