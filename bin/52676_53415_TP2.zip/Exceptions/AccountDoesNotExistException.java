package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description account doesnt exist exception
 */
public class AccountDoesNotExistException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public AccountDoesNotExistException() {
		super();
	}
}
