package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description profile doesnt exist exception
 */
public class ProfileDoesntExistException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	public ProfileDoesntExistException() {
		super();
	}
}
