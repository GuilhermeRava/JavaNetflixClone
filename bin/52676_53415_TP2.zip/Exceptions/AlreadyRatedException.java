package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description already rated program exception
 */
public class AlreadyRatedException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public AlreadyRatedException() {
		super();
	}
}
