package Exceptions;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description not recent watched exception
 */
public class NotRecentWatchedException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public NotRecentWatchedException() {
		super();
	}
}
