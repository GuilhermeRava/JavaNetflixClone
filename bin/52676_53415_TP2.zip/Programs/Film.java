package Programs;
/**
 * 
 * @author 53415 (Guilherme Mazzei) && 52676 (Pedro Silva) <br>
 * @description A Label interface to identify Programs of sub-type Film.
 */
public interface Film extends Program {

}
